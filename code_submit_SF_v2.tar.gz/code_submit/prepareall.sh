#!/bin/bash

chrnum=23	#The number of chromosome in the simulated cell, the value of 23 means 22 autosomes+ X chromosome



#Starting from ATAC/DNase data(genomic length of each chromosome is also needed) to prepare input files for performing simulation for stochastic folding
cd prepare/


cd chrlen/
bash doall.sh $chrnum
cd ..

cd ATAC_data/
bash doall.sh $chrnum
cd ..

cd assign/
bash doall.sh $chrnum
cd ..

cd ../



cd simulation/replica/
bash prepare_simulation.sh $chrnum
cd ../..

