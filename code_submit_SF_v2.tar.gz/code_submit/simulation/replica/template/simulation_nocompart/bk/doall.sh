#!/bin/bash

bash do1.sh 1 1
bash do2.sh 1
bash do3.sh 1
bash do4.sh 1
bash do5.sh 1
bash do6.sh 1
bash do7.sh 1
bash do8.sh 1
bash do9.sh 1
bash do10.sh 1
